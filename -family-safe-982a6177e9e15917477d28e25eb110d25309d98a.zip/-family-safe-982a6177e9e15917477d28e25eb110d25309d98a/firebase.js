import { initializeApp } from "firebase/app";
import {
  initializeAuth,
  getReactNativePersistence,
} from "firebase/auth";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  projectId: "familysafe-a24ce",
  storageBucket: "familysafe-a24ce.firebasestorage.app",

  // දැනට තියෙන API key එක මෙතන තියාගන්න
  apiKey: "AIzaSyAlgYbPJId6lAuH3CTGvZc-ZDNtBcXmUG8",

  appId: "1:676246139820:android:f81bbf77a56de99410009",
  messagingSenderId: "676246139820",
  authDomain: "familysafe-a24ce.firebaseapp.com",
};

const app = initializeApp(firebaseConfig);

export const auth = initializeAuth(app, {
  persistence: getReactNativePersistence(AsyncStorage),
});

export const db = getFirestore(app);
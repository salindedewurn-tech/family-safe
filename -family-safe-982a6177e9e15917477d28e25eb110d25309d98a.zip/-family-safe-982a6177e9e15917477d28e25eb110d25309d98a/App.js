import React, {
  useEffect,
  useRef,
  useState,
} from 'react';

import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  NativeModules,
  AppState,
} from 'react-native';

import {
  onAuthStateChanged,
  signInWithEmailAndPassword,
  signInAnonymously,
} from 'firebase/auth';

import {
  collection,
  doc,
  setDoc,
  addDoc,
  updateDoc,
  query,
  where,
  onSnapshot,
  getDocs,
  serverTimestamp,
} from 'firebase/firestore';

import { auth, db } from './firebase';

import {
  AudioModule,
  setAudioModeAsync,
} from 'expo-audio';

import * as SecureStore from 'expo-secure-store';

import {
  RTCPeerConnection,
  RTCSessionDescription,
  RTCIceCandidate,
  mediaDevices,
} from 'react-native-webrtc';

import InCallManager from 'react-native-incall-manager';

import {
  getMessaging,
  requestPermission,
  registerDeviceForRemoteMessages,
  getToken,
  onTokenRefresh,
  onMessage,
} from '@react-native-firebase/messaging';


/* =========================================================
   NATIVE MODULE
========================================================= */

const {
  VoiceForegroundService,
} = NativeModules;


/* =========================================================
   STORAGE
========================================================= */

const MODE_KEY =
  'family_safe_mode';

const CHILD_PARENT_EMAIL_KEY =
  'family_safe_parent_email';

const CHILD_MIC_SETUP_KEY =
  'family_safe_child_mic_setup';

const LINKED_CHILD_KEY =
  'family_safe_linked_child';

const FCM_TOKEN_KEY =
  'family_safe_fcm_token';


/* =========================================================
   SETTINGS
========================================================= */

const DEBUG_MODE = true;

const HEARTBEAT_INTERVAL_MS = 30000;


/* =========================================================
   METERED ICE
   IMPORTANT:
   Use your current/new Metered credentials here.
========================================================= */

/*
 * IMPORTANT:
 * Do NOT reuse credentials that have been publicly shared.
 */

const METERED_USERNAME =
  'YOUR_NEW_METERED_USERNAME';

const METERED_PASSWORD =
  'YOUR_NEW_METERED_PASSWORD';


const ICE_SERVERS = [
  {
    urls:
      'stun:stun.relay.metered.ca:80',
  },

  {
    urls:
      'turn:global.relay.metered.ca:80',

    username:
      METERED_USERNAME,

    credential:
      METERED_PASSWORD,
  },

  {
    urls:
      'turn:global.relay.metered.ca:80?transport=tcp',

    username:
      METERED_USERNAME,

    credential:
      METERED_PASSWORD,
  },

  {
    urls:
      'turn:global.relay.metered.ca:443',

    username:
      METERED_USERNAME,

    credential:
      METERED_PASSWORD,
  },

  {
    urls:
      'turns:global.relay.metered.ca:443?transport=tcp',

    username:
      METERED_USERNAME,

    credential:
      METERED_PASSWORD,
  },
];


/* =========================================================
   APP
========================================================= */

export default function App() {

  /* =======================================================
     MODE
  ======================================================= */

  const [mode, setMode] =
    useState(undefined);


  /* =======================================================
     AUTH
  ======================================================= */

  const [user, setUser] =
    useState(null);

  const [email, setEmail] =
    useState('');

  const [password, setPassword] =
    useState('');

  const [authLoading, setAuthLoading] =
    useState(false);

  const [authError, setAuthError] =
    useState('');


  /* =======================================================
     CHILD
  ======================================================= */

  const [childParentEmail, setChildParentEmail] =
    useState('');

  const [childReady, setChildReady] =
    useState(false);

  const [childSetupLoading, setChildSetupLoading] =
    useState(false);

  const [microphoneReady, setMicrophoneReady] =
    useState(false);


  /* =======================================================
     PARENT
  ======================================================= */

  const [linkedChildUid, setLinkedChildUid] =
    useState(null);

  const [pairingLoading, setPairingLoading] =
    useState(false);

  const [pairingError, setPairingError] =
    useState('');


  /* =======================================================
     VOICE
  ======================================================= */

  const [voiceStatus, setVoiceStatus] =
    useState('VOICE OFF');

  const [voiceActive, setVoiceActive] =
    useState(false);


  /* =======================================================
     APP STATE
  ======================================================= */

  const [appState, setAppState] =
    useState(AppState.currentState);


  /* =======================================================
     DEBUG
  ======================================================= */

  const [debugLogs, setDebugLogs] =
    useState([]);

  const debugScrollRef =
    useRef(null);


  function addDebugLog(message) {

    const line =
      `${new Date().toLocaleTimeString()}  ${message}`;

    console.log(message);

    setDebugLogs(previous => [
      ...previous.slice(-149),
      line,
    ]);
  }


  /* =======================================================
     DEBUG AUTO SCROLL
  ======================================================= */

  useEffect(() => {

    const timer =
      setTimeout(() => {

        debugScrollRef.current?.scrollToEnd({
          animated: false,
        });

      }, 30);

    return () =>
      clearTimeout(timer);

  }, [debugLogs]);


  /* =======================================================
     APP STATE LISTENER
  ======================================================= */

  useEffect(() => {

    const subscription =
      AppState.addEventListener(
        'change',
        nextState => {

          addDebugLog(
            `APP STATE: ${nextState}`
          );

          setAppState(nextState);
        }
      );


    return () =>
      subscription.remove();

  }, []);


  /* =======================================================
     WEBRTC / FIREBASE REFS
  ======================================================= */

  const peerRef =
    useRef(null);

  const localStreamRef =
    useRef(null);

  const sessionUnsubscribeRef =
    useRef(null);

  const remoteIceUnsubscribeRef =
    useRef(null);

  const requestUnsubscribeRef =
    useRef(null);

  const activeSessionRef =
    useRef(null);

  const activeRequestRef =
    useRef(null);

  const remoteIceQueueRef =
    useRef([]);


  /* =======================================================
     FOREGROUND SERVICE
========================================================= */

  function startChildForegroundService(
    sessionId
  ) {

    try {

      if (
        !VoiceForegroundService ||
        typeof VoiceForegroundService.start !==
          'function'
      ) {

        addDebugLog(
          'FOREGROUND SERVICE MODULE NOT AVAILABLE'
        );

        return false;
      }


      if (!sessionId) {

        addDebugLog(
          'FOREGROUND SERVICE START FAILED: SESSION ID MISSING'
        );

        return false;
      }


      /*
       * IMPORTANT:
       * Native VoiceForegroundService.start()
       * requires the active voice session ID.
       */

      VoiceForegroundService.start(
        sessionId
      );


      addDebugLog(
        `CHILD: FOREGROUND VOICE SERVICE STARTED - ${sessionId}`
      );


      return true;

    } catch (error) {

      addDebugLog(
        `FOREGROUND SERVICE START ERROR: ${
          error?.message || error
        }`
      );

      return false;
    }
  }


  function stopChildForegroundService() {

    try {

      if (
        !VoiceForegroundService ||
        typeof VoiceForegroundService.stop !==
          'function'
      ) {

        addDebugLog(
          'FOREGROUND SERVICE MODULE NOT AVAILABLE'
        );

        return;
      }


      VoiceForegroundService.stop();


      addDebugLog(
        'CHILD: FOREGROUND VOICE SERVICE STOPPED'
      );

    } catch (error) {

      addDebugLog(
        `FOREGROUND SERVICE STOP ERROR: ${
          error?.message || error
        }`
      );
    }
  }


  /* =======================================================
     LOAD SAVED MODE
  ======================================================= */

  useEffect(() => {

    let mounted = true;


    async function loadMode() {

      try {

        const saved =
          await SecureStore.getItemAsync(
            MODE_KEY
          );


        if (!mounted) {
          return;
        }


        if (
          saved === 'PARENT' ||
          saved === 'CHILD'
        ) {

          setMode(saved);

        } else {

          setMode(null);
        }


      } catch (error) {

        addDebugLog(
          `MODE LOAD ERROR: ${
            error?.message || error
          }`
        );


        if (mounted) {
          setMode(null);
        }
      }
    }


    loadMode();


    return () => {
      mounted = false;
    };

  }, []);


  /* =======================================================
     AUTH
  ======================================================= */

  useEffect(() => {

    if (
      mode === undefined ||
      !mode
    ) {
      return;
    }


    let mounted = true;


    const unsubscribe =
      onAuthStateChanged(
        auth,
        async currentUser => {

          if (!mounted) {
            return;
          }


          setUser(currentUser);


          /* -------------------------------------------------
             CHILD
          ------------------------------------------------- */

          if (
            mode === 'CHILD' &&
            !currentUser
          ) {

            try {

              addDebugLog(
                'CHILD: ANONYMOUS LOGIN'
              );


              await signInAnonymously(
                auth
              );

            } catch (error) {

              addDebugLog(
                `CHILD LOGIN ERROR: ${
                  error?.message || error
                }`
              );
            }


            return;
          }


          if (
            mode === 'CHILD' &&
            currentUser
          ) {

            await initializeChild(
              currentUser.uid
            );


            return;
          }


          /* -------------------------------------------------
             PARENT
          ------------------------------------------------- */

          if (
            mode === 'PARENT' &&
            currentUser
          ) {

            try {

              await setDoc(
                doc(
                  db,
                  'users',
                  currentUser.uid
                ),
                {
                  appType: 'A',

                  email:
                    currentUser.email || '',

                  updatedAt:
                    serverTimestamp(),
                },
                {
                  merge: true,
                }
              );


              addDebugLog(
                'PARENT: PROFILE READY'
              );

            } catch (error) {

              addDebugLog(
                `PARENT PROFILE ERROR: ${
                  error?.message || error
                }`
              );
            }
          }
        }
      );


    return () => {

      mounted = false;

      unsubscribe();

    };

  }, [mode]);


  /* =======================================================
     CHILD FCM
  ======================================================= */

  useEffect(() => {

    if (
      mode !== 'CHILD' ||
      !user ||
      !childReady
    ) {
      return;
    }


    let mounted = true;

    let unsubscribeTokenRefresh = null;

    let unsubscribeForegroundMessage = null;


    async function setupFCM() {

      try {

        const fcm =
          getMessaging();


        addDebugLog(
          'CHILD: FCM INITIALIZATION'
        );


        try {

          const permission =
            await requestPermission(fcm);


          addDebugLog(
            `CHILD: FCM PERMISSION=${permission}`
          );

        } catch (error) {

          addDebugLog(
            `FCM PERMISSION ERROR: ${
              error?.message || error
            }`
          );
        }


        await registerDeviceForRemoteMessages(
          fcm
        );


        const token =
          await getToken(fcm);


        if (!token) {

          addDebugLog(
            'CHILD: FCM TOKEN EMPTY'
          );

          return;
        }


        await SecureStore.setItemAsync(
          FCM_TOKEN_KEY,
          token
        );


        await setDoc(
          doc(
            db,
            'users',
            user.uid
          ),
          {
            appType: 'B',

            fcmToken:
              token,

            fcmUpdatedAt:
              serverTimestamp(),

            updatedAt:
              serverTimestamp(),
          },
          {
            merge: true,
          }
        );


        addDebugLog(
          'CHILD: FCM TOKEN REGISTERED'
        );


        unsubscribeTokenRefresh =
          onTokenRefresh(
            fcm,
            async refreshedToken => {

              try {

                await SecureStore.setItemAsync(
                  FCM_TOKEN_KEY,
                  refreshedToken
                );


                await setDoc(
                  doc(
                    db,
                    'users',
                    user.uid
                  ),
                  {
                    fcmToken:
                      refreshedToken,

                    fcmUpdatedAt:
                      serverTimestamp(),

                    updatedAt:
                      serverTimestamp(),
                  },
                  {
                    merge: true,
                  }
                );


                addDebugLog(
                  'CHILD: FCM TOKEN REFRESHED'
                );

              } catch (error) {

                addDebugLog(
                  `FCM TOKEN UPDATE ERROR: ${
                    error?.message || error
                  }`
                );
              }
            }
          );


        unsubscribeForegroundMessage =
          onMessage(
            fcm,
            async remoteMessage => {

              if (!mounted) {
                return;
              }


              const data =
                remoteMessage?.data || {};


              const type =
                data?.type;


              addDebugLog(
                `CHILD: FCM MESSAGE type=${
                  type || 'none'
                }`
              );


              if (
                type ===
                'VOICE_RECOVERY'
              ) {

                await recoverPendingVoiceRequest();

                return;
              }


              if (
                type ===
                'VOICE_STOP'
              ) {

                await closeVoice();


                activeRequestRef.current =
                  null;

                activeSessionRef.current =
                  null;
              }
            }
          );


      } catch (error) {

        addDebugLog(
          `FCM ERROR: ${
            error?.message || error
          }`
        );
      }
    }


    setupFCM();


    return () => {

      mounted = false;


      if (
        unsubscribeTokenRefresh
      ) {
        unsubscribeTokenRefresh();
      }


      if (
        unsubscribeForegroundMessage
      ) {
        unsubscribeForegroundMessage();
      }

    };

  }, [
    mode,
    user,
    childReady,
  ]);


  /* =======================================================
     CHILD ACTIVE RECOVERY
  ======================================================= */

  useEffect(() => {

    if (
      mode !== 'CHILD' ||
      !user ||
      !childReady ||
      appState !== 'active'
    ) {
      return;
    }


    const timer =
      setTimeout(() => {

        addDebugLog(
          'CHILD: ACTIVE RECOVERY CHECK'
        );


        recoverPendingVoiceRequest();

      }, 700);


    return () =>
      clearTimeout(timer);

  }, [
    mode,
    user,
    childReady,
    appState,
  ]);


  /* =======================================================
     CHILD HEARTBEAT
  ======================================================= */

  useEffect(() => {

    if (
      mode !== 'CHILD' ||
      !user ||
      !childReady ||
      appState !== 'active'
    ) {
      return;
    }


    let cancelled = false;


    async function heartbeat() {

      try {

        await setDoc(
          doc(
            db,
            'users',
            user.uid
          ),
          {
            appType: 'B',

            parentEmail:
              childParentEmail || '',

            lastSeenAt:
              serverTimestamp(),

            online:
              true,
          },
          {
            merge: true,
          }
        );


        if (!cancelled) {

          addDebugLog(
            'CHILD: HEARTBEAT UPDATED'
          );
        }

      } catch (error) {

        if (!cancelled) {

          addDebugLog(
            `CHILD HEARTBEAT ERROR: ${
              error?.message || error
            }`
          );
        }
      }
    }


    heartbeat();


    const timer =
      setInterval(
        heartbeat,
        HEARTBEAT_INTERVAL_MS
      );


    return () => {

      cancelled = true;

      clearInterval(timer);
    };

  }, [
    mode,
    user,
    childReady,
    appState,
    childParentEmail,
  ]);


  /* =======================================================
     MICROPHONE
  ======================================================= */

  async function requestMicrophone() {

    try {

      const current =
        await AudioModule.getRecordingPermissionsAsync();


      if (
        current?.granted
      ) {

        setMicrophoneReady(true);


        addDebugLog(
          'MICROPHONE: GRANTED'
        );


        return true;
      }


      const result =
        await AudioModule.requestRecordingPermissionsAsync();


      const granted =
        result?.granted === true;


      setMicrophoneReady(
        granted
      );


      addDebugLog(
        `MICROPHONE RESULT=${granted}`
      );


      return granted;

    } catch (error) {

      addDebugLog(
        `MICROPHONE ERROR: ${
          error?.message || error
        }`
      );


      return false;
    }
  }


  /* =======================================================
     CHILD INITIALIZATION
  ======================================================= */

  async function initializeChild(uid) {

    try {

      addDebugLog(
        'CHILD: INITIALIZATION START'
      );


      const savedParentEmail =
        await SecureStore.getItemAsync(
          CHILD_PARENT_EMAIL_KEY
        );


      const micSetup =
        await SecureStore.getItemAsync(
          CHILD_MIC_SETUP_KEY
        );


      await setDoc(
        doc(
          db,
          'users',
          uid
        ),
        {
          appType: 'B',

          parentEmail:
            savedParentEmail || '',

          updatedAt:
            serverTimestamp(),

          lastSeenAt:
            serverTimestamp(),

          online:
            true,
        },
        {
          merge: true,
        }
      );


      if (!savedParentEmail) {

        setChildReady(false);

        setVoiceStatus(
          'FIRST SETUP REQUIRED'
        );


        addDebugLog(
          'CHILD: WAITING FOR PARENT EMAIL'
        );


        return;
      }


      setChildParentEmail(
        savedParentEmail
      );


      if (
        micSetup === 'granted'
      ) {

        setMicrophoneReady(
          true
        );

      } else {

        const granted =
          await requestMicrophone();


        if (!granted) {

          setChildReady(false);

          setVoiceStatus(
            'MICROPHONE PERMISSION REQUIRED'
          );


          return;
        }


        await SecureStore.setItemAsync(
          CHILD_MIC_SETUP_KEY,
          'granted'
        );


        setMicrophoneReady(
          true
        );
      }


      setChildReady(
        true
      );


      setVoiceStatus(
        'READY FOR PARENT VOICE'
      );


      addDebugLog(
        'CHILD: READY'
      );

    } catch (error) {

      addDebugLog(
        `CHILD INIT ERROR: ${
          error?.message || error
        }`
      );
    }
  }


  /* =======================================================
     CHILD FIRST SETUP
  ======================================================= */

  async function saveChildSetup() {

    const parentEmail =
      childParentEmail
        .trim()
        .toLowerCase();


    if (!parentEmail) {

      setVoiceStatus(
        'PARENT EMAIL REQUIRED'
      );


      return;
    }


    try {

      setChildSetupLoading(
        true
      );


      const currentUser =
        auth.currentUser;


      if (!currentUser) {

        throw new Error(
          'FIREBASE USER NOT AVAILABLE'
        );
      }


      await SecureStore.setItemAsync(
        CHILD_PARENT_EMAIL_KEY,
        parentEmail
      );


      const granted =
        await requestMicrophone();


      if (!granted) {

        setVoiceStatus(
          'MICROPHONE PERMISSION REQUIRED'
        );


        return;
      }


      await SecureStore.setItemAsync(
        CHILD_MIC_SETUP_KEY,
        'granted'
      );


      await setDoc(
        doc(
          db,
          'users',
          currentUser.uid
        ),
        {
          appType: 'B',

          parentEmail,

          updatedAt:
            serverTimestamp(),

          lastSeenAt:
            serverTimestamp(),

          online:
            true,
        },
        {
          merge: true,
        }
      );


      setMicrophoneReady(
        true
      );


      setChildReady(
        true
      );


      setVoiceStatus(
        'READY FOR PARENT VOICE'
      );


      addDebugLog(
        'CHILD: SETUP COMPLETE'
      );

    } catch (error) {

      addDebugLog(
        `CHILD SETUP ERROR: ${
          error?.message || error
        }`
      );


      setVoiceStatus(
        'CHILD SETUP ERROR'
      );

    } finally {

      setChildSetupLoading(
        false
      );
    }
  }


  /* =======================================================
     MODE
  ======================================================= */

  async function selectMode(
    selectedMode
  ) {

    try {

      await SecureStore.setItemAsync(
        MODE_KEY,
        selectedMode
      );


      setMode(
        selectedMode
      );

    } catch (error) {

      addDebugLog(
        `MODE SAVE ERROR: ${
          error?.message || error
        }`
      );
    }
  }


  /* =======================================================
     AUDIO
  ======================================================= */

  async function configureAudio(
    recording
  ) {

    try {

      await setAudioModeAsync({
        allowsRecording:
          recording,

        playsInSilentMode:
          true,

        shouldPlayInSilentMode:
          true,

        shouldPlayInBackground:
          true,

        interruptionMode:
          'doNotMix',
      });


      InCallManager.start({
        media: 'audio',
      });


      InCallManager.setForceSpeakerphoneOn(
        true
      );


      try {

        InCallManager.setMicrophoneMute(
          !recording
        );

      } catch {}

    } catch (error) {

      addDebugLog(
        `AUDIO ERROR: ${
          error?.message || error
        }`
      );
    }
  }


  /* =======================================================
     WEBRTC PEER
  ======================================================= */

  function createPeer() {

    const pc =
      new RTCPeerConnection({
        iceServers:
          ICE_SERVERS,
      });


    pc.oniceconnectionstatechange =
      () => {

        const state =
          pc.iceConnectionState;


        addDebugLog(
          `ICE STATE: ${state}`
        );


        if (
          state ===
            'connected' ||
          state ===
            'completed'
        ) {

          setVoiceActive(
            true
          );


          setVoiceStatus(
            'VOICE CONNECTED'
          );
        }


        if (
          state ===
          'checking'
        ) {

          setVoiceStatus(
            'VOICE CONNECTING'
          );
        }


        if (
          state ===
          'disconnected'
        ) {

          setVoiceStatus(
            'VOICE RECONNECTING'
          );
        }


        if (
          state ===
          'failed'
        ) {

          setVoiceActive(
            false
          );


          setVoiceStatus(
            'VOICE FAILED'
          );
        }
      };


    pc.onconnectionstatechange =
      () => {

        const state =
          pc.connectionState;


        addDebugLog(
          `PEER STATE: ${state}`
        );


        if (
          state ===
          'connected'
        ) {

          setVoiceActive(
            true
          );


          setVoiceStatus(
            'VOICE CONNECTED'
          );
        }


        if (
          state ===
          'connecting'
        ) {

          setVoiceStatus(
            'VOICE CONNECTING'
          );
        }


        if (
          state ===
          'disconnected'
        ) {

          setVoiceStatus(
            'VOICE RECONNECTING'
          );
        }


        if (
          state ===
          'failed'
        ) {

          setVoiceActive(
            false
          );


          setVoiceStatus(
            'VOICE FAILED'
          );
        }
      };


    pc.ontrack =
      event => {

        const track =
          event?.track;


        if (
          track?.kind ===
          'audio'
        ) {

          track.enabled =
            true;


          addDebugLog(
            'REMOTE AUDIO TRACK ACTIVE'
          );
        }
      };


    pc.onsignalingstatechange =
      () => {

        addDebugLog(
          `SIGNALING STATE: ${pc.signalingState}`
        );
      };


    pc.onicegatheringstatechange =
      () => {

        addDebugLog(
          `ICE GATHERING: ${pc.iceGatheringState}`
        );
      };


    peerRef.current =
      pc;


    return pc;
  }


  /* =======================================================
     VOICE CLEANUP
  ======================================================= */

  async function closeVoice() {

    try {

      if (
        sessionUnsubscribeRef.current
      ) {

        sessionUnsubscribeRef.current();

        sessionUnsubscribeRef.current =
          null;
      }


      if (
        remoteIceUnsubscribeRef.current
      ) {

        remoteIceUnsubscribeRef.current();

        remoteIceUnsubscribeRef.current =
          null;
      }


      if (
        localStreamRef.current
      ) {

        localStreamRef.current
          .getTracks()
          .forEach(track => {

            try {
              track.stop();
            } catch {}

          });
      }


      localStreamRef.current =
        null;


      if (
        peerRef.current
      ) {

        try {
          peerRef.current.close();
        } catch {}

        peerRef.current =
          null;
      }


      try {

        InCallManager.setMicrophoneMute(
          true
        );


        InCallManager.stop();

      } catch {}


      if (
        mode === 'CHILD'
      ) {

        stopChildForegroundService();
      }


      remoteIceQueueRef.current =
        [];


      setVoiceActive(
        false
      );


      setVoiceStatus(
        mode === 'CHILD'
          ? 'READY FOR PARENT VOICE'
          : 'VOICE OFF'
      );

    } catch (error) {

      addDebugLog(
        `VOICE CLEANUP ERROR: ${
          error?.message || error
        }`
      );
    }
  }


  /* =======================================================
     REMOTE ICE
  ======================================================= */

  async function addRemoteCandidate(
    candidateData
  ) {

    const pc =
      peerRef.current;


    if (
      !pc ||
      !candidateData
    ) {
      return;
    }


    try {

      if (
        !pc.remoteDescription
      ) {

        remoteIceQueueRef.current.push(
          candidateData
        );


        addDebugLog(
          'ICE: REMOTE CANDIDATE QUEUED'
        );


        return;
      }


      await pc.addIceCandidate(
        new RTCIceCandidate(
          candidateData
        )
      );


      addDebugLog(
        'ICE: REMOTE CANDIDATE ADDED'
      );

    } catch (error) {

      addDebugLog(
        `REMOTE ICE ERROR: ${
          error?.message || error
        }`
      );
    }
  }


  async function flushRemoteIce() {

    const pc =
      peerRef.current;


    if (
      !pc ||
      !pc.remoteDescription
    ) {
      return;
    }


    const queue =
      remoteIceQueueRef.current;


    remoteIceQueueRef.current =
      [];


    for (
      const candidate
      of queue
    ) {

      try {

        await pc.addIceCandidate(
          new RTCIceCandidate(
            candidate
          )
        );

      } catch (error) {

        addDebugLog(
          `ICE QUEUE ERROR: ${
            error?.message || error
          }`
        );
      }
    }


    if (
      queue.length
    ) {

      addDebugLog(
        `ICE: FLUSHED ${queue.length} CANDIDATE(S)`
      );
    }
  }


  /* =======================================================
     PARENT CHILD SEARCH
  ======================================================= */

  async function connectChild() {

    if (!user) {
      return;
    }


    try {

      setPairingLoading(
        true
      );


      setPairingError(
        ''
      );


      const parentEmail =
        user.email
          ?.trim()
          .toLowerCase();


      if (!parentEmail) {

        throw new Error(
          'PARENT EMAIL NOT AVAILABLE'
        );
      }


      const q =
        query(
          collection(
            db,
            'users'
          ),
          where(
            'appType',
            '==',
            'B'
          ),
          where(
            'parentEmail',
            '==',
            parentEmail
          )
        );


      const snapshot =
        await getDocs(q);


      if (
        snapshot.empty
      ) {

        setPairingError(
          'CHILD NOT FOUND'
        );


        return;
      }


      const children =
        snapshot.docs.map(
          childDoc => {

            const data =
              childDoc.data();


            const lastSeen =
              data?.lastSeenAt
                ?.toMillis?.() ||
              0;


            const updated =
              data?.updatedAt
                ?.toMillis?.() ||
              0;


            return {
              uid:
                childDoc.id,

              sortTime:
                Math.max(
                  lastSeen,
                  updated
                ),
            };
          }
        );


      children.sort(
        (a, b) =>
          b.sortTime -
          a.sortTime
      );


      const latest =
        children[0];


      if (!latest) {

        throw new Error(
          'CHILD NOT FOUND'
        );
      }


      await SecureStore.setItemAsync(
        LINKED_CHILD_KEY,
        latest.uid
      );


      await setDoc(
        doc(
          db,
          'users',
          user.uid
        ),
        {
          linkedChildUid:
            latest.uid,

          updatedAt:
            serverTimestamp(),
        },
        {
          merge: true,
        }
      );


      setLinkedChildUid(
        latest.uid
      );


      addDebugLog(
        `PARENT: CHILD CONNECTED ${latest.uid}`
      );

    } catch (error) {

      setPairingError(
        error?.message ||
        'CHILD LINK ERROR'
      );

    } finally {

      setPairingLoading(
        false
      );
    }
  }


  /* =======================================================
     LOAD CURRENT CHILD
  ======================================================= */

  useEffect(() => {

    if (
      mode !== 'PARENT' ||
      !user
    ) {
      return;
    }


    let cancelled =
      false;


    async function loadLatestChild() {

      try {

        const parentEmail =
          user.email
            ?.trim()
            .toLowerCase();


        if (!parentEmail) {
          return;
        }


        const q =
          query(
            collection(
              db,
              'users'
            ),
            where(
              'appType',
              '==',
              'B'
            ),
            where(
              'parentEmail',
              '==',
              parentEmail
            )
          );


        const snapshot =
          await getDocs(q);


        if (cancelled) {
          return;
        }


        if (
          snapshot.empty
        ) {

          setLinkedChildUid(
            null
          );


          await SecureStore.deleteItemAsync(
            LINKED_CHILD_KEY
          );


          return;
        }


        const children =
          snapshot.docs.map(
            childDoc => {

              const data =
                childDoc.data();


              return {
                uid:
                  childDoc.id,

                sortTime:
                  Math.max(
                    data?.lastSeenAt
                      ?.toMillis?.() ||
                      0,

                    data?.updatedAt
                      ?.toMillis?.() ||
                      0
                  ),
              };
            }
          );


        children.sort(
          (a, b) =>
            b.sortTime -
            a.sortTime
        );


        const latest =
          children[0];


        if (!latest) {
          return;
        }


        setLinkedChildUid(
          latest.uid
        );


        await SecureStore.setItemAsync(
          LINKED_CHILD_KEY,
          latest.uid
        );


        addDebugLog(
          `PARENT: LATEST CHILD=${latest.uid}`
        );

      } catch (error) {

        if (!cancelled) {

          addDebugLog(
            `CHILD LOAD ERROR: ${
              error?.message || error
            }`
          );
        }
      }
    }


    loadLatestChild();


    return () => {
      cancelled = true;
    };

  }, [
    mode,
    user,
    appState,
  ]);


  /* =======================================================
     PARENT START VOICE
  ======================================================= */

  async function startVoiceRequest() {

    if (
      mode !== 'PARENT' ||
      !user
    ) {
      return;
    }


    if (
      !linkedChildUid
    ) {

      setVoiceStatus(
        'CHILD NOT LINKED'
      );


      addDebugLog(
        'PARENT: CHILD NOT LINKED'
      );


      return;
    }


    if (
      voiceActive ||
      activeRequestRef.current ||
      activeSessionRef.current
    ) {

      addDebugLog(
        'PARENT: VOICE ALREADY ACTIVE'
      );


      return;
    }


    try {

      setVoiceStatus(
        'VOICE REQUESTING'
      );


      const requestRef =
        await addDoc(
          collection(
            db,
            'voiceRequests'
          ),
          {
            app1Uid:
              user.uid,

            app2Uid:
              linkedChildUid,

            status:
              'pending',

            createdAt:
              serverTimestamp(),

            updatedAt:
              serverTimestamp(),
          }
        );


      activeRequestRef.current =
        requestRef.id;


      addDebugLog(
        `PARENT: VOICE REQUEST ${requestRef.id}`
      );

    } catch (error) {

      setVoiceStatus(
        'VOICE ERROR'
      );


      addDebugLog(
        `VOICE REQUEST ERROR: ${
          error?.message || error
        }`
      );
    }
  }


  /* =======================================================
     CHILD REQUEST PROCESSOR
  ======================================================= */

  async function processChildVoiceRequest(
    requestId,
    data
  ) {

    if (
      mode !== 'CHILD' ||
      !user ||
      !childReady
    ) {
      return;
    }


    if (
      activeRequestRef.current ||
      activeSessionRef.current
    ) {
      return;
    }


    activeRequestRef.current =
      requestId;


    try {

      setVoiceStatus(
        'VOICE REQUEST RECEIVED'
      );


      const sessionRef =
        await addDoc(
          collection(
            db,
            'voiceSessions'
          ),
          {
            requestId,

            app1Uid:
              data.app1Uid,

            app2Uid:
              user.uid,

            status:
              'created',

            createdAt:
              serverTimestamp(),

            updatedAt:
              serverTimestamp(),
          }
        );


      activeSessionRef.current =
        sessionRef.id;


      await updateDoc(
        doc(
          db,
          'voiceRequests',
          requestId
        ),
        {
          status:
            'accepted',

          sessionId:
            sessionRef.id,

          updatedAt:
            serverTimestamp(),
        }
      );


      addDebugLog(
        `CHILD: SESSION ${sessionRef.id}`
      );


      await startChildVoice(
        sessionRef.id
      );

    } catch (error) {

      addDebugLog(
        `CHILD REQUEST ERROR: ${
          error?.message || error
        }`
      );


      activeRequestRef.current =
        null;


      activeSessionRef.current =
        null;


      setVoiceStatus(
        'VOICE ERROR'
      );
    }
  }


  /* =======================================================
     PENDING RECOVERY
  ======================================================= */

  async function recoverPendingVoiceRequest() {

    if (
      mode !== 'CHILD' ||
      !user ||
      !childReady
    ) {
      return;
    }


    if (
      activeRequestRef.current ||
      activeSessionRef.current
    ) {
      return;
    }


    try {

      const q =
        query(
          collection(
            db,
            'voiceRequests'
          ),
          where(
            'app2Uid',
            '==',
            user.uid
          ),
          where(
            'status',
            '==',
            'pending'
          )
        );


      const snapshot =
        await getDocs(q);


      addDebugLog(
        `CHILD: PENDING REQUESTS=${snapshot.size}`
      );


      for (
        const requestDoc
        of snapshot.docs
      ) {

        if (
          activeRequestRef.current ||
          activeSessionRef.current
        ) {
          break;
        }


        await processChildVoiceRequest(
          requestDoc.id,
          requestDoc.data()
        );
      }

    } catch (error) {

      addDebugLog(
        `RECOVERY ERROR: ${
          error?.message || error
        }`
      );
    }
  }


  /* =======================================================
     CHILD REQUEST LISTENER
  ======================================================= */

  useEffect(() => {

    if (
      mode !== 'CHILD' ||
      !user ||
      !childReady
    ) {
      return;
    }


    addDebugLog(
      'CHILD: REQUEST LISTENER STARTED'
    );


    const q =
      query(
        collection(
          db,
          'voiceRequests'
        ),
        where(
          'app2Uid',
          '==',
          user.uid
        ),
        where(
          'status',
          '==',
          'pending'
        )
      );


    const unsubscribe =
      onSnapshot(
        q,

        snapshot => {

          addDebugLog(
            `CHILD: REQUEST SNAPSHOT=${snapshot.size}`
          );


          snapshot.docChanges().forEach(
            change => {

              if (
                change.type !== 'added'
              ) {
                return;
              }


              addDebugLog(
                `CHILD: VOICE REQUEST RECEIVED ${change.doc.id}`
              );


              processChildVoiceRequest(
                change.doc.id,
                change.doc.data()
              );
            }
          );
        },

        error => {

          addDebugLog(
            `REQUEST LISTENER ERROR: ${
              error?.message || error
            }`
          );
        }
      );


    requestUnsubscribeRef.current =
      unsubscribe;


    return () => {

      addDebugLog(
        'CHILD: REQUEST LISTENER STOPPED'
      );


      unsubscribe();


      if (
        requestUnsubscribeRef.current ===
        unsubscribe
      ) {

        requestUnsubscribeRef.current =
          null;
      }
    };

  }, [
    mode,
    user,
    childReady,
  ]);


  /* =======================================================
     CHILD WEBRTC
  ======================================================= */

  async function startChildVoice(
    sessionId
  ) {

    try {

      /*
       * IMPORTANT:
       * Foreground service starts ONLY here,
       * after Parent's voice request is accepted.
       *
       * sessionId is passed to the native service.
       */

      const serviceStarted =
        startChildForegroundService(
          sessionId
        );


      if (!serviceStarted) {

        addDebugLog(
          'CHILD: FOREGROUND SERVICE START FAILED'
        );
      }


      await configureAudio(
        true
      );


      const granted =
        await requestMicrophone();


      if (!granted) {

        throw new Error(
          'MICROPHONE PERMISSION REQUIRED'
        );
      }


      const pc =
        createPeer();


      const stream =
        await mediaDevices.getUserMedia({
          audio: true,
          video: false,
        });


      localStreamRef.current =
        stream;


      stream
        .getAudioTracks()
        .forEach(track => {

          track.enabled =
            true;


          pc.addTrack(
            track,
            stream
          );
        });


      pc.onicecandidate =
        async event => {

          if (
            !event.candidate
          ) {
            return;
          }


          await addDoc(
            collection(
              db,
              'voiceSessions',
              sessionId,
              'app2IceCandidates'
            ),
            {
              candidate:
                event.candidate.toJSON(),

              createdAt:
                serverTimestamp(),
            }
          );


          addDebugLog(
            'CHILD: ICE CANDIDATE SENT'
          );
        };


      sessionUnsubscribeRef.current =
        onSnapshot(
          doc(
            db,
            'voiceSessions',
            sessionId
          ),

          async snapshot => {

            if (
              !snapshot.exists()
            ) {
              return;
            }


            const data =
              snapshot.data();


            if (
              data.status ===
              'stopped'
            ) {

              await closeVoice();


              activeRequestRef.current =
                null;


              activeSessionRef.current =
                null;


              return;
            }


            if (
              !data.offer ||
              pc.remoteDescription
            ) {
              return;
            }


            try {

              await pc.setRemoteDescription(
                new RTCSessionDescription(
                  data.offer
                )
              );


              await flushRemoteIce();


              const answer =
                await pc.createAnswer();


              await pc.setLocalDescription(
                answer
              );


              await updateDoc(
                doc(
                  db,
                  'voiceSessions',
                  sessionId
                ),
                {
                  answer: {
                    type:
                      answer.type,

                    sdp:
                      answer.sdp,
                  },

                  status:
                    'answer-sent',

                  updatedAt:
                    serverTimestamp(),
                }
              );


              addDebugLog(
                'CHILD: ANSWER SENT'
              );

            } catch (error) {

              addDebugLog(
                `CHILD ANSWER ERROR: ${
                  error?.message ||
                  error
                }`
              );
            }
          }
        );


      remoteIceUnsubscribeRef.current =
        onSnapshot(
          collection(
            db,
            'voiceSessions',
            sessionId,
            'app1IceCandidates'
          ),

          snapshot => {

            snapshot
              .docChanges()
              .forEach(
                change => {

                  if (
                    change.type !==
                    'added'
                  ) {
                    return;
                  }


                  const data =
                    change.doc.data();


                  if (
                    data.candidate
                  ) {

                    addRemoteCandidate(
                      data.candidate
                    );
                  }
                }
              );
          }
        );


      setVoiceStatus(
        'VOICE CONNECTING'
      );

    } catch (error) {

      addDebugLog(
        `CHILD WEBRTC ERROR: ${
          error?.message || error
        }`
      );


      await closeVoice();


      activeRequestRef.current =
        null;


      activeSessionRef.current =
        null;


      setVoiceStatus(
        'VOICE ERROR'
      );
    }
  }


  /* =======================================================
     PARENT REQUEST LISTENER
  ======================================================= */

  useEffect(() => {

    if (
      mode !== 'PARENT' ||
      !user
    ) {
      return;
    }


    const q =
      query(
        collection(
          db,
          'voiceRequests'
        ),
        where(
          'app1Uid',
          '==',
          user.uid
        )
      );


    const unsubscribe =
      onSnapshot(
        q,

        snapshot => {

          snapshot
            .docChanges()
            .forEach(change => {

              if (
                change.type !==
                  'added' &&
                change.type !==
                  'modified'
              ) {
                return;
              }


              const data =
                change.doc.data();


              const requestId =
                change.doc.id;


              if (
                data.status ===
                  'accepted' &&
                data.sessionId &&
                activeRequestRef.current ===
                  requestId &&
                activeSessionRef.current ===
                  null
              ) {

                startParentVoice(
                  data.sessionId
                );
              }


              if (
                data.status ===
                'stopped'
              ) {

                closeVoice();


                activeRequestRef.current =
                  null;


                activeSessionRef.current =
                  null;
              }
            });
        },

        error => {

          addDebugLog(
            `PARENT REQUEST LISTENER ERROR: ${
              error?.message || error
            }`
          );
        }
      );


    return () =>
      unsubscribe();

  }, [
    mode,
    user,
  ]);


  /* =======================================================
     PARENT WEBRTC
  ======================================================= */

  async function startParentVoice(
    sessionId
  ) {

    try {

      activeSessionRef.current =
        sessionId;


      await configureAudio(
        false
      );


      const pc =
        createPeer();


      pc.addTransceiver(
        'audio',
        {
          direction:
            'recvonly',
        }
      );


      pc.onicecandidate =
        async event => {

          if (
            !event.candidate
          ) {
            return;
          }


          await addDoc(
            collection(
              db,
              'voiceSessions',
              sessionId,
              'app1IceCandidates'
            ),
            {
              candidate:
                event.candidate.toJSON(),

              createdAt:
                serverTimestamp(),
            }
          );


          addDebugLog(
            'PARENT: ICE CANDIDATE SENT'
          );
        };


      const offer =
        await pc.createOffer();


      await pc.setLocalDescription(
        offer
      );


      await updateDoc(
        doc(
          db,
          'voiceSessions',
          sessionId
        ),
        {
          offer: {
            type:
              offer.type,

            sdp:
              offer.sdp,
          },

          status:
            'offer-created',

          updatedAt:
            serverTimestamp(),
        }
      );


      sessionUnsubscribeRef.current =
        onSnapshot(
          doc(
            db,
            'voiceSessions',
            sessionId
          ),

          async snapshot => {

            if (
              !snapshot.exists()
            ) {
              return;
            }


            const data =
              snapshot.data();


            if (
              data.status ===
              'stopped'
            ) {

              await closeVoice();


              activeRequestRef.current =
                null;


              activeSessionRef.current =
                null;


              return;
            }


            if (
              !data.answer ||
              pc.remoteDescription
            ) {
              return;
            }


            try {

              await pc.setRemoteDescription(
                new RTCSessionDescription(
                  data.answer
                )
              );


              await flushRemoteIce();


              addDebugLog(
                'PARENT: ANSWER SET'
              );

            } catch (error) {

              addDebugLog(
                `PARENT ANSWER ERROR: ${
                  error?.message ||
                  error
                }`
              );
            }
          }
        );


      remoteIceUnsubscribeRef.current =
        onSnapshot(
          collection(
            db,
            'voiceSessions',
            sessionId,
            'app2IceCandidates'
          ),

          snapshot => {

            snapshot
              .docChanges()
              .forEach(
                change => {

                  if (
                    change.type !==
                    'added'
                  ) {
                    return;
                  }


                  const data =
                    change.doc.data();


                  if (
                    data.candidate
                  ) {

                    addRemoteCandidate(
                      data.candidate
                    );
                  }
                }
              );
          }
        );


      setVoiceStatus(
        'VOICE CONNECTING'
      );

    } catch (error) {

      addDebugLog(
        `PARENT WEBRTC ERROR: ${
          error?.message || error
        }`
      );


      await closeVoice();


      activeRequestRef.current =
        null;


      activeSessionRef.current =
        null;


      setVoiceStatus(
        'VOICE ERROR'
      );
    }
  }


  /* =======================================================
     STOP VOICE
  ======================================================= */

  async function stopVoice() {

    const requestId =
      activeRequestRef.current;


    const sessionId =
      activeSessionRef.current;


    try {

      if (requestId) {

        await updateDoc(
          doc(
            db,
            'voiceRequests',
            requestId
          ),
          {
            status:
              'stopped',

            updatedAt:
              serverTimestamp(),
          }
        );
      }


      if (sessionId) {

        await updateDoc(
          doc(
            db,
            'voiceSessions',
            sessionId
          ),
          {
            status:
              'stopped',

            updatedAt:
              serverTimestamp(),
          }
        );
      }

    } catch (error) {

      addDebugLog(
        `STOP ERROR: ${
          error?.message || error
        }`
      );
    }


    await closeVoice();


    activeRequestRef.current =
      null;


    activeSessionRef.current =
      null;


    setVoiceStatus(
      'VOICE OFF'
    );


    addDebugLog(
      'PARENT: VOICE STOPPED'
    );
  }


  /* =======================================================
     UNMOUNT CLEANUP
  ======================================================= */

  useEffect(() => {

    return () => {

      try {

        requestUnsubscribeRef
          .current
          ?.();


        sessionUnsubscribeRef
          .current
          ?.();


        remoteIceUnsubscribeRef
          .current
          ?.();


        localStreamRef
          .current
          ?.getTracks()
          ?.forEach(
            track => {

              try {
                track.stop();
              } catch {}

            }
          );


        peerRef
          .current
          ?.close();


        try {
          InCallManager.stop();
        } catch {}


        if (
          mode === 'CHILD'
        ) {

          stopChildForegroundService();
        }

      } catch {}
    };

  }, []);


  /* =======================================================
     NO MODE YET
  ======================================================= */

  if (
    mode === undefined
  ) {

    return null;
  }


  /* =======================================================
     MODE SELECT
  ======================================================= */

  if (!mode) {

    return (
      <View style={styles.screen}>

        <Text style={styles.title}>
          FAMILY SAFE
        </Text>


        <Text style={styles.text}>
          SELECT DEVICE
        </Text>


        <TouchableOpacity
          style={styles.button}
          onPress={() =>
            selectMode('PARENT')
          }
        >

          <Text style={styles.buttonText}>
            PARENT
          </Text>

        </TouchableOpacity>


        <TouchableOpacity
          style={styles.button}
          onPress={() =>
            selectMode('CHILD')
          }
        >

          <Text style={styles.buttonText}>
            CHILD
          </Text>

        </TouchableOpacity>

      </View>
    );
  }


  /* =======================================================
     CHILD SETUP
  ======================================================= */

  if (
    mode === 'CHILD' &&
    !childReady
  ) {

    if (
      voiceStatus ===
      'FIRST SETUP REQUIRED'
    ) {

      return (
        <View style={styles.screen}>

          <Text style={styles.title}>
            FAMILY SAFE
          </Text>


          <Text style={styles.label}>
            CHILD SETUP
          </Text>


          <Text style={styles.text}>
            ENTER PARENT EMAIL
          </Text>


          <TextInput
            style={styles.input}
            placeholder="PARENT EMAIL"
            placeholderTextColor="#777"
            value={childParentEmail}
            onChangeText={
              setChildParentEmail
            }
            autoCapitalize="none"
            keyboardType="email-address"
            editable={
              !childSetupLoading
            }
          />


          <TouchableOpacity
            style={styles.button}
            onPress={
              saveChildSetup
            }
            disabled={
              childSetupLoading
            }
          >

            <Text style={styles.buttonText}>
              {childSetupLoading
                ? 'SETTING UP...'
                : 'CONTINUE'}
            </Text>

          </TouchableOpacity>

        </View>
      );
    }


    return (
      <View style={styles.screen}>

        <Text style={styles.title}>
          FAMILY SAFE
        </Text>


        <Text style={styles.label}>
          CHILD
        </Text>


        <Text style={styles.status}>
          {voiceStatus}
        </Text>

      </View>
    );
  }


  /* =======================================================
     CHILD UI
  ======================================================= */

  if (
    mode === 'CHILD'
  ) {

    return (
      <View style={styles.screen}>

        <Text style={styles.title}>
          FAMILY SAFE
        </Text>


        <Text style={styles.label}>
          CHILD
        </Text>


        <Text style={styles.status}>
          {voiceStatus}
        </Text>


        {DEBUG_MODE && (
          <View style={styles.debugPanel}>

            <Text style={styles.debugTitle}>
              LIVE DEBUG
            </Text>


            <ScrollView
              ref={
                debugScrollRef
              }
              style={
                styles.debugScroll
              }
              contentContainerStyle={
                styles.debugContent
              }
            >

              {debugLogs.map(
                (log, index) => (

                  <Text
                    key={index}
                    style={
                      styles.debugText
                    }
                  >
                    {log}
                  </Text>

                )
              )}

            </ScrollView>

          </View>
        )}

      </View>
    );
  }


  /* =======================================================
     PARENT LOGIN
  ======================================================= */

  if (!user) {

    async function login() {

      if (
        !email.trim() ||
        !password
      ) {

        setAuthError(
          'EMAIL AND PASSWORD REQUIRED'
        );


        return;
      }


      try {

        setAuthLoading(
          true
        );


        setAuthError(
          ''
        );


        await signInWithEmailAndPassword(
          auth,
          email.trim(),
          password
        );


        addDebugLog(
          'PARENT: LOGIN SUCCESS'
        );

      } catch (error) {

        setAuthError(
          error?.message ||
          'LOGIN FAILED'
        );

      } finally {

        setAuthLoading(
          false
        );
      }
    }


    return (
      <View style={styles.screen}>

        <Text style={styles.title}>
          FAMILY SAFE
        </Text>


        <Text style={styles.label}>
          PARENT LOGIN
        </Text>


        <TextInput
          style={styles.input}
          placeholder="EMAIL"
          placeholderTextColor="#777"
          value={email}
          onChangeText={setEmail}
          autoCapitalize="none"
          keyboardType="email-address"
        />


        <TextInput
          style={styles.input}
          placeholder="PASSWORD"
          placeholderTextColor="#777"
          value={password}
          onChangeText={setPassword}
          secureTextEntry
        />


        <TouchableOpacity
          style={styles.button}
          onPress={login}
          disabled={authLoading}
        >

          <Text style={styles.buttonText}>
            {authLoading
              ? 'LOGIN...'
              : 'LOGIN'}
          </Text>

        </TouchableOpacity>


        {!!authError && (
          <Text style={styles.error}>
            {authError}
          </Text>
        )}

      </View>
    );
  }


  /* =======================================================
     PARENT CHILD LINK
  ======================================================= */

  if (!linkedChildUid) {

    return (
      <View style={styles.screen}>

        <Text style={styles.title}>
          FAMILY SAFE
        </Text>


        <Text style={styles.label}>
          PARENT
        </Text>


        <Text style={styles.text}>
          CHILD NOT CONNECTED
        </Text>


        <TouchableOpacity
          style={styles.button}
          onPress={
            connectChild
          }
          disabled={
            pairingLoading
          }
        >

          <Text style={styles.buttonText}>
            {pairingLoading
              ? 'CONNECTING...'
              : 'CONNECT CHILD'}
          </Text>

        </TouchableOpacity>


        {!!pairingError && (
          <Text style={styles.error}>
            {pairingError}
          </Text>
        )}

      </View>
    );
  }


  /* =======================================================
     PARENT DASHBOARD
  ======================================================= */

  return (
    <View style={styles.parentContainer}>

      <View style={styles.parentLeft}>

        <Text style={styles.parentTitle}>
          FAMILY SAFE
        </Text>


        <Text style={styles.parentLabel}>
          PARENT
        </Text>


        <Text style={styles.parentCodeLabel}>
          CHILD
        </Text>


        <Text style={styles.parentCode}>
          LINKED
        </Text>


        <Text style={styles.parentStatus}>
          {voiceStatus}
        </Text>


        {!voiceActive ? (

          <TouchableOpacity
            style={
              styles.parentButton
            }
            onPress={
              startVoiceRequest
            }
          >

            <Text style={styles.buttonText}>
              VOICE START
            </Text>

          </TouchableOpacity>

        ) : (

          <TouchableOpacity
            style={
              styles.parentStopButton
            }
            onPress={
              stopVoice
            }
          >

            <Text style={styles.stopText}>
              VOICE STOP
            </Text>

          </TouchableOpacity>

        )}

      </View>


      <View
        style={
          styles.parentDebugPanel
        }
      >

        <Text
          style={
            styles.parentDebugTitle
          }
        >
          LIVE DEBUG
        </Text>


        <ScrollView
          ref={
            debugScrollRef
          }
          style={
            styles.parentDebugScroll
          }
          contentContainerStyle={
            styles.parentDebugContent
          }
        >

          {debugLogs.map(
            (log, index) => (

              <Text
                key={index}
                style={
                  styles.parentDebugText
                }
              >
                {log}
              </Text>

            )
          )}

        </ScrollView>

      </View>

    </View>
  );
}


/* =========================================================
   STYLES
========================================================= */

const styles =
  StyleSheet.create({

    screen: {
      flex: 1,
      backgroundColor: '#080808',
      alignItems: 'center',
      justifyContent: 'center',
      padding: 24,
    },


    title: {
      color: '#00ff66',
      fontSize: 24,
      fontWeight: '700',
      letterSpacing: 2,
      marginBottom: 20,
    },


    label: {
      color: '#00ff66',
      fontSize: 13,
      marginBottom: 12,
    },


    text: {
      color: '#aaa',
      fontSize: 12,
      marginBottom: 16,
      textAlign: 'center',
    },


    input: {
      width: '90%',
      borderWidth: 1,
      borderColor: '#00ff66',
      backgroundColor: '#101010',
      color: '#00ff66',
      paddingHorizontal: 12,
      paddingVertical: 11,
      marginVertical: 5,
    },


    button: {
      minWidth: 190,
      borderWidth: 1,
      borderColor: '#00ff66',
      backgroundColor: '#061006',
      paddingVertical: 13,
      paddingHorizontal: 22,
      alignItems: 'center',
      marginTop: 12,
    },


    buttonText: {
      color: '#00ff66',
      fontSize: 13,
      fontWeight: '700',
      letterSpacing: 1,
    },


    stopText: {
      color: '#ff6666',
      fontSize: 13,
      fontWeight: '700',
      letterSpacing: 1,
    },


    status: {
      color: '#00ff66',
      fontSize: 15,
      fontWeight: '600',
      marginBottom: 18,
    },


    error: {
      color: '#ff6666',
      fontSize: 11,
      marginTop: 15,
      textAlign: 'center',
    },


    debugPanel: {
      position: 'absolute',
      left: 8,
      right: 8,
      bottom: 8,
      height: 230,
      backgroundColor: '#020502',
      borderWidth: 1,
      borderColor: '#00ff66',
      padding: 8,
    },


    debugTitle: {
      color: '#00ff66',
      fontSize: 11,
      fontWeight: '700',
      letterSpacing: 1,
      marginBottom: 5,
    },


    debugScroll: {
      flex: 1,
    },


    debugContent: {
      paddingBottom: 5,
    },


    debugText: {
      color: '#00ff66',
      fontSize: 9,
      lineHeight: 13,
      fontFamily: 'monospace',
    },


    parentContainer: {
      flex: 1,
      flexDirection: 'row',
      backgroundColor: '#080808',
    },


    parentLeft: {
      width: '30%',
      minWidth: 150,
      backgroundColor: '#080808',
      borderRightWidth: 1,
      borderRightColor: '#00ff66',
      paddingHorizontal: 10,
      paddingTop: 28,
      alignItems: 'center',
    },


    parentTitle: {
      color: '#00ff66',
      fontSize: 18,
      fontWeight: '700',
      letterSpacing: 1,
      textAlign: 'center',
      marginBottom: 8,
    },


    parentLabel: {
      color: '#00ff66',
      fontSize: 12,
      letterSpacing: 1,
      marginBottom: 25,
    },


    parentCodeLabel: {
      color: '#666',
      fontSize: 9,
      textAlign: 'center',
    },


    parentCode: {
      color: '#00ff66',
      fontSize: 20,
      fontWeight: '700',
      letterSpacing: 3,
      marginTop: 7,
      marginBottom: 20,
    },


    parentStatus: {
      color: '#00ff66',
      fontSize: 10,
      textAlign: 'center',
      marginBottom: 5,
    },


    parentButton: {
      width: '100%',
      borderWidth: 1,
      borderColor: '#00ff66',
      backgroundColor: '#061006',
      paddingVertical: 11,
      paddingHorizontal: 4,
      alignItems: 'center',
      marginTop: 12,
    },


    parentStopButton: {
      width: '100%',
      borderWidth: 1,
      borderColor: '#ff5555',
      backgroundColor: '#180000',
      paddingVertical: 11,
      paddingHorizontal: 4,
      alignItems: 'center',
      marginTop: 12,
    },


    parentDebugPanel: {
      width: '70%',
      flex: 1,
      backgroundColor: '#020502',
      padding: 12,
    },


    parentDebugTitle: {
      color: '#00ff66',
      fontSize: 13,
      fontWeight: '700',
      letterSpacing: 1,
      paddingBottom: 8,
      borderBottomWidth: 1,
      borderBottomColor: '#123d20',
    },


    parentDebugScroll: {
      flex: 1,
      marginTop: 8,
    },


    parentDebugContent: {
      paddingBottom: 20,
    },


    parentDebugText: {
      color: '#00ff66',
      fontSize: 10,
      lineHeight: 15,
      fontFamily: 'monospace',
    },

  });
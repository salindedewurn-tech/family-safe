package com.malithsalinde.familysafe

import android.content.Intent
import android.util.Log
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import androidx.core.content.ContextCompat

class FamilySafeMessagingService :
    FirebaseMessagingService() {

    companion object {
        private const val TAG = "FamilySafeFCM"
    }

    override fun onMessageReceived(
        message: RemoteMessage
    ) {
        super.onMessageReceived(message)

        Log.d(
            TAG,
            "FCM MESSAGE RECEIVED"
        )

        val type =
            message.data["type"]

        if (type.isNullOrBlank()) {

            Log.d(
                TAG,
                "FCM MESSAGE HAS NO TYPE"
            )

            return
        }

        Log.d(
            TAG,
            "FCM TYPE: $type"
        )

        when (type) {

            "VOICE_RECOVERY" -> {

                val sessionId =
                    message.data["sessionId"]

                if (!sessionId.isNullOrBlank()) {

                    Log.d(
                        TAG,
                        "VOICE_RECOVERY SESSION: $sessionId"
                    )

                    startVoiceRecovery(
                        sessionId
                    )

                } else {

                    Log.e(
                        TAG,
                        "VOICE_RECOVERY SESSION ID MISSING"
                    )
                }
            }

            "VOICE_STOP" -> {

                Log.d(
                    TAG,
                    "VOICE_STOP RECEIVED"
                )

                stopVoiceRecovery()
            }

            else -> {

                Log.d(
                    TAG,
                    "UNKNOWN FCM TYPE: $type"
                )
            }
        }
    }

    private fun startVoiceRecovery(
        sessionId: String
    ) {

        Log.d(
            TAG,
            "STARTING VOICE FOREGROUND SERVICE"
        )

        val intent =
            Intent(
                this,
                VoiceForegroundService::class.java
            ).apply {

                action =
                    VoiceForegroundService.ACTION_START

                putExtra(
                    VoiceForegroundService.EXTRA_SESSION_ID,
                    sessionId
                )
            }

        try {

            ContextCompat.startForegroundService(
                this,
                intent
            )

            Log.d(
                TAG,
                "VOICE FOREGROUND SERVICE INTENT SENT"
            )

        } catch (error: Exception) {

            Log.e(
                TAG,
                "VOICE RECOVERY ERROR",
                error
            )
        }
    }

    private fun stopVoiceRecovery() {

        Log.d(
            TAG,
            "STOPPING VOICE FOREGROUND SERVICE"
        )

        val intent =
            Intent(
                this,
                VoiceForegroundService::class.java
            ).apply {

                action =
                    VoiceForegroundService.ACTION_STOP
            }

        try {

            startService(
                intent
            )

            Log.d(
                TAG,
                "VOICE STOP INTENT SENT"
            )

        } catch (error: Exception) {

            Log.e(
                TAG,
                "VOICE STOP ERROR",
                error
            )
        }
    }

    override fun onNewToken(
        token: String
    ) {
        super.onNewToken(token)

        Log.d(
            TAG,
            "FCM TOKEN RECEIVED"
        )

        /*
         * Token is handled by the
         * React Native Firebase integration.
         */
    }
}
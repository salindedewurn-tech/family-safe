package com.malithsalinde.familysafe

import android.content.Intent
import android.util.Log
import androidx.core.content.ContextCompat
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod

class VoiceForegroundServiceModule(
    reactContext: ReactApplicationContext
) : ReactContextBaseJavaModule(reactContext) {

    companion object {
        private const val TAG = "FamilySafeVoice"
    }

    override fun getName(): String {
        return "VoiceForegroundService"
    }

    @ReactMethod
    fun start(sessionId: String) {

        Log.d(
            TAG,
            "MODULE START CALLED - sessionId=$sessionId"
        )

        if (sessionId.isBlank()) {

            Log.e(
                TAG,
                "MODULE START FAILED - SESSION ID EMPTY"
            )

            return
        }

        try {

            val context =
                reactApplicationContext

            val intent =
                Intent(
                    context,
                    VoiceForegroundService::class.java
                ).apply {

                    action =
                        VoiceForegroundService.ACTION_START

                    putExtra(
                        VoiceForegroundService.EXTRA_SESSION_ID,
                        sessionId
                    )
                }

            ContextCompat.startForegroundService(
                context,
                intent
            )

            Log.d(
                TAG,
                "FOREGROUND SERVICE INTENT SENT"
            )

        } catch (error: Exception) {

            Log.e(
                TAG,
                "FOREGROUND SERVICE START ERROR",
                error
            )
        }
    }

    @ReactMethod
    fun stop() {

        Log.d(
            TAG,
            "MODULE STOP CALLED"
        )

        try {

            val context =
                reactApplicationContext

            val intent =
                Intent(
                    context,
                    VoiceForegroundService::class.java
                ).apply {

                    action =
                        VoiceForegroundService.ACTION_STOP
                }

            context.startService(
                intent
            )

            Log.d(
                TAG,
                "FOREGROUND SERVICE STOP INTENT SENT"
            )

        } catch (error: Exception) {

            Log.e(
                TAG,
                "FOREGROUND SERVICE STOP ERROR",
                error
            )
        }
    }
}
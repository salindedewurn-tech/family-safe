package com.malithsalinde.familysafe

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat

class VoiceForegroundService : Service() {

    companion object {

        const val ACTION_START =
            "com.malithsalinde.familysafe.action.START_VOICE"

        const val ACTION_STOP =
            "com.malithsalinde.familysafe.action.STOP_VOICE"

        const val EXTRA_SESSION_ID =
            "session_id"

        private const val CHANNEL_ID =
            "family_safe_voice_channel"

        private const val NOTIFICATION_ID =
            1001
    }

    private var wakeLock: PowerManager.WakeLock? = null

    private var activeSessionId: String? = null

    override fun onCreate() {
        super.onCreate()

        android.util.Log.d(
            "FamilySafeVoice",
            "SERVICE onCreate()"
        )

        createNotificationChannel()

        val notification: Notification =
            NotificationCompat.Builder(
                this,
                CHANNEL_ID
            )
                .setSmallIcon(
                    R.drawable.ic_notification_message
                )
                .setContentTitle(
                    "New message"
                )
                .setOngoing(true)
                .setAutoCancel(false)
                .setOnlyAlertOnce(true)
                .setSilent(true)
                .setCategory(
                    NotificationCompat.CATEGORY_SERVICE
                )
                .setPriority(
                    NotificationCompat.PRIORITY_LOW
                )
                .build()

        try {

            if (
                Build.VERSION.SDK_INT >=
                Build.VERSION_CODES.Q
            ) {

                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                )

            } else {

                @Suppress("DEPRECATION")
                startForeground(
                    NOTIFICATION_ID,
                    notification
                )
            }

            android.util.Log.d(
                "FamilySafeVoice",
                "START FOREGROUND SUCCESS"
            )

        } catch (error: Exception) {

            android.util.Log.e(
                "FamilySafeVoice",
                "START FOREGROUND FAILED",
                error
            )

            stopSelf()
        }
    }

    override fun onStartCommand(
        intent: Intent?,
        flags: Int,
        startId: Int
    ): Int {

        android.util.Log.d(
            "FamilySafeVoice",
            "SERVICE onStartCommand() action=${intent?.action}"
        )

        when (intent?.action) {

            ACTION_START -> {

                val sessionId =
                    intent.getStringExtra(
                        EXTRA_SESSION_ID
                    )

                if (!sessionId.isNullOrBlank()) {

                    activeSessionId =
                        sessionId

                    acquireWakeLock()

                    android.util.Log.d(
                        "FamilySafeVoice",
                        "SERVICE RUNNING - SESSION: $sessionId"
                    )

                } else {

                    android.util.Log.d(
                        "FamilySafeVoice",
                        "SERVICE START - SESSION ID MISSING"
                    )
                }
            }

            ACTION_STOP -> {

                android.util.Log.d(
                    "FamilySafeVoice",
                    "SERVICE STOP REQUESTED"
                )

                activeSessionId = null

                releaseWakeLock()

                if (
                    Build.VERSION.SDK_INT >=
                    Build.VERSION_CODES.N
                ) {

                    stopForeground(
                        STOP_FOREGROUND_REMOVE
                    )

                } else {

                    @Suppress("DEPRECATION")
                    stopForeground(true)
                }

                stopSelf()
            }
        }

        return START_STICKY
    }

    private fun acquireWakeLock() {

        try {

            if (wakeLock?.isHeld == true) {
                return
            }

            val powerManager =
                getSystemService(
                    POWER_SERVICE
                ) as PowerManager

            wakeLock =
                powerManager.newWakeLock(
                    PowerManager.PARTIAL_WAKE_LOCK,
                    "FamilySafe::VoiceWakeLock"
                )

            wakeLock?.setReferenceCounted(
                false
            )

            wakeLock?.acquire()

            android.util.Log.d(
                "FamilySafeVoice",
                "WAKELOCK ACQUIRED"
            )

        } catch (error: Exception) {

            android.util.Log.e(
                "FamilySafeVoice",
                "WAKELOCK ERROR",
                error
            )
        }
    }

    private fun releaseWakeLock() {

        try {

            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
            }

        } catch (error: Exception) {

            android.util.Log.e(
                "FamilySafeVoice",
                "WAKELOCK RELEASE ERROR",
                error
            )
        }

        wakeLock = null

        android.util.Log.d(
            "FamilySafeVoice",
            "WAKELOCK RELEASED"
        )
    }

    override fun onTaskRemoved(
        rootIntent: Intent?
    ) {

        android.util.Log.d(
            "FamilySafeVoice",
            "APP TASK REMOVED - SESSION: $activeSessionId"
        )

        super.onTaskRemoved(
            rootIntent
        )
    }

    override fun onDestroy() {

        android.util.Log.d(
            "FamilySafeVoice",
            "SERVICE DESTROYED"
        )

        activeSessionId = null

        releaseWakeLock()

        super.onDestroy()
    }

    override fun onBind(
        intent: Intent?
    ): IBinder? {
        return null
    }

    private fun createNotificationChannel() {

        if (
            Build.VERSION.SDK_INT >=
            Build.VERSION_CODES.O
        ) {

            val channel =
                NotificationChannel(
                    CHANNEL_ID,
                    "New message",
                    NotificationManager.IMPORTANCE_LOW
                )

            channel.description =
                "Family Safe background voice service"

            channel.setSound(
                null,
                null
            )

            channel.enableVibration(
                false
            )

            channel.setShowBadge(
                false
            )

            val manager =
                getSystemService(
                    NotificationManager::class.java
                )

            manager.createNotificationChannel(
                channel
            )

            android.util.Log.d(
                "FamilySafeVoice",
                "NOTIFICATION CHANNEL CREATED"
            )
        }
    }
}